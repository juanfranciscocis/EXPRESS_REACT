// controllers
const mongoose = require('mongoose'); // incorporar mongoose a la REST API
const users = mongoose.model('user'); // el modelo me permite interactuar con la colección users

// crear usuarios
const userCreate = (req, res) => {
    res
        .status(201)
        .json({"status":"success create"});
};

// listar usuarios
const userList = (req, res) => {
    users
        .find()
        .exec()
        .then((objetoUsuario)=>{
            res
                .status(200)
                .json(objetoUsuario);
        })
        .catch((err) => {
            res
                .status(404)
                .json({"status":"error list"});
            console.log('Error al listar usuarios; ', req.params.userid);
        })

};

// leer usuario
const userRead = (req, res) => {
    users
        .findById(req.params.userid)
        .exec()
        .then((objetoUsuario)=>{
            res
                .status(200)
                .json(objetoUsuario);
        })
        .catch((err) => {
            res
                .status(404)
                .json({"status":"error read"});
            console.log('Error al buscar el usuario; ', req.params.userid);
        })
};

// modificar usuarios
const userUpdate = (req, res) => {
    res
        .status(200)
        .json({"status":"success update"});
};

// eliminar usuarios
const userDelete = (req, res) => {
    res
        .status(204)
        .json({"status":"success delete"});
};

module.exports = {
    userCreate, // crear usuario
    userList,   // listar usuarios
    userRead,   // leer usuario
    userUpdate, // actualizar usuario
    userDelete  // eliminar usuario
}